from flask import Flask, render_template request
import requests

app = Flask(__name__)

@app.route(rule:'/', methods=['GET', 'POST'])
def index():
    weather_data = {}
    if request.method == 'POST':
        city = request.form['city']
        api_key = "8c580fc5c75f779c7e48b17b40b8b211"
        weather_url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric&lang=es"
        response = requests.get(weather_url)
        if response.ok:
            data = response.json()
            weather_data = {
                'city': city,
                'temperature': data['main']['temp'],
                'description': data['weather'][0]['description'],
                'icon': data['weather'][0]['icon'],
            } 

    return render_template(template_name_or_list: 'index.html',
                           weather_data=weather_data)


if __name__== '__main__':
    app.run(debug=True)